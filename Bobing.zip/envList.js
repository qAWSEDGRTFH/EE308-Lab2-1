const envList = [{"envId":"cloud1-9gs2tna3c5253ba3","alias":"cloud1"}]
const isMac = false
module.exports = {
    envList,
    isMac
}